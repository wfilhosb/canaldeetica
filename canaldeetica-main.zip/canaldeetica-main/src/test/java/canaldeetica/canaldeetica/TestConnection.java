package canaldeetica.canaldeetica;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class TestConnection {
	public static void main(String[] args) {
		String url = "jdbc:postgresql://191.252.185.30:5432/bdcanaldeetica";
		String user = "sistemacanal";
		String password = "canaldeetica2024";

		try (Connection conn = DriverManager.getConnection(url, user, password)) {
			if (conn != null) {
				System.out.println("Connected to the database!");
			} else {
				System.out.println("Failed to make connection!");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
