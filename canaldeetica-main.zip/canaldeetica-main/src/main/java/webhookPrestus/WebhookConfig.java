package webhookPrestus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jakarta.annotation.PostConstruct;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "webhookPrestus, dao, login")
public class WebhookConfig implements WebMvcConfigurer {
	private static final Logger logger = LoggerFactory.getLogger(WebhookConfig.class);

	@PostConstruct
	public void init() {
		logger.info("WebhookConfig initialized");
	}
}
