package webhookPrestus;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import jakarta.annotation.PostConstruct;
import org.springframework.http.MediaType;
import model.RelatoPayloadPrestus;

@RestController
@RequestMapping("/webhookprestus")
public class WebhookPrestusController {
	private static final Logger logger = LoggerFactory.getLogger(WebhookPrestusController.class);

	@PostConstruct
	public void init() {
		((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger("org.springframework.web"))
				.setLevel(ch.qos.logback.classic.Level.DEBUG);
		((ch.qos.logback.classic.Logger) org.slf4j.LoggerFactory.getLogger("webhookPrestus"))
				.setLevel(ch.qos.logback.classic.Level.DEBUG);
		logger.info("WebhookPrestusController inicializado");
	}

	private final WebhookPrestusService webhookPrestusService;

	@Autowired
	public WebhookPrestusController(WebhookPrestusService webhookPrestusService) {
		this.webhookPrestusService = webhookPrestusService;
		logger.info("WebhookPrestusController construído");
	}

	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> receberWebhook(@RequestBody RelatoPayloadPrestus relatoPayloadPrestus) {
		logger.info("Recebida requisição POST em /webhookprestus");
		try {
			webhookPrestusService.savePayloadPrestus(relatoPayloadPrestus);
			return ResponseEntity.ok().body("{\"message\": \"Dados recebidos com sucesso!\"}");
		} catch (Exception e) {
			return ResponseEntity.badRequest()
					.body("{\"error\": \"Erro ao processar os dados: " + e.getMessage() + "\"}");
		}
	}

	@GetMapping(path = "/teste", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> testar() {
		return ResponseEntity.ok().body("{\"message\": \"Webhook funcionando!\"}");
	}
}