package webhookPrestus;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Date;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.CategoriaRelatoDAO;
import dao.EmpresaDAO;
import dao.FonteRelatoDAO;
import dao.RelatoDAO;
import dao.UsuarioDAO;
import model.CategoriaRelato;
import model.Empresa;
import model.FonteRelato;
import model.Relato;
import model.RelatoPayloadPrestus;
import model.Usuario;

@Service
public class WebhookPrestusService {

    private static final Logger logger = LoggerFactory.getLogger(WebhookPrestusService.class);

    private RelatoDAO relatoDAO;

    private UsuarioDAO usuarioDAO;

    private EmpresaDAO empresaDAO;

    private FonteRelatoDAO fonteRelatoDAO;

    private CategoriaRelatoDAO categoriaRelatoDAO;

    public void savePayloadPrestus(RelatoPayloadPrestus relatoPayloadPrestus) {
        try {
            Relato relato = new Relato();

            // Buscando usuário padrão (Sistema)
            Usuario usuario = usuarioDAO.buscarPorCodigo(1);

            // Buscando empresa pelo código enviado no payload
            Empresa empresa = buscarEmpresa(relatoPayloadPrestus);

            // Buscando fonte de relato padrão da Prestus
            FonteRelato fonteRelato = fonteRelatoDAO.buscarPorCodigo(4);

            // Buscando categoria do relato pelo código
            CategoriaRelato categoriaRelato = buscarCategoriaRelato(relatoPayloadPrestus);

            // Convertendo data e hora do JSON para `dtCadastro`
            Date dtCadastro = converterDataHora(relatoPayloadPrestus.getDate(), relatoPayloadPrestus.getTime());

            // Cálculo da data de vencimento com base na categoria
            Date dtVencimento = (categoriaRelato != null && categoriaRelato.getPrazoDias() > 0)
                    ? calculateDueDate(categoriaRelato.getPrazoDias())
                    : dtCadastro;

            // Populando objeto `Relato`
            relato.setUsuario(usuario);
            relato.setEmpresa(empresa);
            relato.setFonteRelato(fonteRelato);
            relato.setCategoriaRelato(categoriaRelato);
            relato.setDtCadastro(dtCadastro);
            relato.setDtVencimento(dtVencimento);
            relato.setTitulo(relatoPayloadPrestus.getA().get("3")); // A linha 3
            relato.setDescRelato(relatoPayloadPrestus.getA().get("10")); // A linha 10
            relato.setChaveAcesso(relatoPayloadPrestus.getId());

            // Persistindo no banco de dados
            relatoDAO.save(relato);
            logger.info("Relato salvo com sucesso: {}", relato.getChaveAcesso());

        } catch (Exception e) {
            logger.error("Erro ao processar payload do webhook", e);
        }
    }

    private Empresa buscarEmpresa(RelatoPayloadPrestus relatoPayloadPrestus) {
        int codigoEmpresa = 0;
        if (relatoPayloadPrestus.getA().get("2") != null && !relatoPayloadPrestus.getA().get("2").isEmpty()) {
            try {
                codigoEmpresa = Integer.parseInt(relatoPayloadPrestus.getA().get("2"));
                return empresaDAO.buscarPorCodigo(codigoEmpresa);
            } catch (NumberFormatException e) {
                logger.warn("Código da empresa inválido, usando empresa padrão (ID 3)");
            }
        }
        return empresaDAO.buscarPorCodigo(3);
    }

    private CategoriaRelato buscarCategoriaRelato(RelatoPayloadPrestus relatoPayloadPrestus) {
        int codigoCategoriaRelato = 0;
        if (relatoPayloadPrestus.getA().get("5") != null && !relatoPayloadPrestus.getA().get("5").isEmpty()) {
            try {
                codigoCategoriaRelato = Integer.parseInt(relatoPayloadPrestus.getA().get("5"));
                return categoriaRelatoDAO.buscarPorCodigo(codigoCategoriaRelato);
            } catch (NumberFormatException e) {
                logger.warn("Código da categoria de relato inválido, usando categoria padrão (ID 34)");
            }
        }
        return categoriaRelatoDAO.buscarPorCodigo(34);
    }

    private Date converterDataHora(String date, String time) {
        String dateTimeString = date + " " + time;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse(dateTimeString, formatter);
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    // Método para calcular a data de vencimento considerando apenas dias úteis
    private Date calculateDueDate(int prazo) {
        LocalDate date = LocalDate.now();
        int addedDays = 0;
        while (addedDays < prazo) {
            date = date.plusDays(1);
            if (isBusinessDay(date)) {
                addedDays++;
            }
        }
        return java.sql.Date.valueOf(date);
    }

    // Método para verificar se uma data é um dia útil
    private boolean isBusinessDay(LocalDate date) {
        final Set<LocalDate> HOLIDAYS = new HashSet<>(Arrays.asList(
            LocalDate.of(2025, 1, 1),  // Ano Novo
            LocalDate.of(2025, 3, 3),  // Carnaval
            LocalDate.of(2025, 3, 4),  // Carnaval
            LocalDate.of(2025, 3, 5),  // Quarta-feira de Cinzas (meio-dia)
            LocalDate.of(2025, 4, 18), // Sexta-feira Santa
            LocalDate.of(2025, 4, 21), // Tiradentes
            LocalDate.of(2025, 5, 1),  // Dia do Trabalho
            LocalDate.of(2025, 6, 19), // Corpus Christi
            LocalDate.of(2025, 9, 7),  // Independência do Brasil
            LocalDate.of(2025, 10, 12), // Nossa Senhora Aparecida
            LocalDate.of(2025, 11, 2),  // Finados
            LocalDate.of(2025, 11, 15), // Proclamação da República
            LocalDate.of(2025, 12, 25)  // Natal
        ));
        return !EnumSet.of(DayOfWeek.SATURDAY, DayOfWeek.SUNDAY).contains(date.getDayOfWeek()) && !HOLIDAYS.contains(date);
    }
}
