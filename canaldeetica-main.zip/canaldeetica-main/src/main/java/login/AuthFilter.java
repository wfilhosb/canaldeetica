package login;

import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        String loginURI = req.getContextPath() + "/index.xhtml";
        String cpprURI = req.getContextPath() + "/ccpr";
        String resourcesURI = req.getContextPath() + "/javax.faces.resource";
        String converterURI = req.getContextPath() + "/converter";
        String apiURI = req.getContextPath() + "/canaldeetica";  // Ajustado para permitir acesso à API

        boolean loggedIn = (session != null) && (session.getAttribute("usuarioLogado") != null);
        boolean loginRequest = req.getRequestURI().equals(loginURI);
        boolean resourceRequest = req.getRequestURI().startsWith(req.getContextPath() + "/resources");
        boolean primefacesResourceRequest = req.getRequestURI().startsWith(resourcesURI);
        boolean cpprRequest = req.getRequestURI().startsWith(cpprURI);
        boolean converterRequest = req.getRequestURI().startsWith(converterURI);
        boolean apiRequest = req.getRequestURI().startsWith(apiURI);  // Agora garantindo que todas as requisições da API passem

        if (loggedIn || loginRequest || resourceRequest || primefacesResourceRequest || cpprRequest || converterRequest || apiRequest) {
            chain.doFilter(request, response);
        } else {
            res.sendRedirect(loginURI);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }
}
