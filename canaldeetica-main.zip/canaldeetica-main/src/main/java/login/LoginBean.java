package login;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

import org.springframework.web.context.annotation.SessionScope;

import canaldeetica.canaldeetica.HibernateUtil;
import jakarta.annotation.ManagedBean;
//import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import model.Usuario;

@ManagedBean(value = "loginBean")
@SessionScope
public class LoginBean implements Serializable{
	
    private static final long serialVersionUID = 1L;

	private String login;
	private String senha;
	private Usuario usuarioLogado;
	private String nomeUsuario;

	@PersistenceContext
	private EntityManager em = HibernateUtil.getEntityManager();

	public String autenticar() {
		try {
			Usuario usuario = (Usuario) em
					.createQuery("SELECT u FROM Usuario u WHERE u.login = :login AND u.senha = :senha")
					.setParameter("login", login).setParameter("senha", senha).getSingleResult();

			if (usuario != null) {
				FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("usuarioLogado", usuario);
				this.nomeUsuario = usuario.getNomeCompleto();
				this.usuarioLogado = usuario;
				System.out.println("OLHA A AQUI O USUARIO LOGADO" + usuarioLogado.getNivel());
				return "homepage?faces-redirect=true";
			} else {
				FacesMessage msg = new FacesMessage("Login ou senha inválidos.");
				FacesContext.getCurrentInstance().addMessage(null, msg);
				return null;
			}
		} catch (NoResultException e) {
			FacesMessage msg = new FacesMessage("Login ou senha inválidos.");
			FacesContext.getCurrentInstance().addMessage(null, msg);
			return null;
		}
	}

	public String logout() {
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		return "index?faces-redirect=true";
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public Usuario getUsuarioLogado() {
		return usuarioLogado;
	}

	public void setUsuarioLogado(Usuario usuarioLogado) {
		this.usuarioLogado = usuarioLogado;
	}

	public String getNomeUsuario() {
		return nomeUsuario;
	}

	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
}
