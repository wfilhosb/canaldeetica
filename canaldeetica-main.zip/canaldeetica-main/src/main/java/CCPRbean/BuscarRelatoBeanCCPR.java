package CCPRbean;

public class BuscarRelatoBeanCCPR {
	private String chaveAcesso;

	// Getter e Setter
	public String getChaveAcesso() {
		return chaveAcesso;
	}

	public void setChaveAcesso(String chaveAcesso) {
		this.chaveAcesso = chaveAcesso;
	}

	// Método para redirecionar com parâmetro
	public String redirecionarComChaveAcesso() {
		return "detalharelatos.xhtml?faces-redirect=true&codigoRelato=" + chaveAcesso;
	}
}
