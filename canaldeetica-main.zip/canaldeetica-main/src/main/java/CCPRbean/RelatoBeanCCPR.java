package CCPRbean;

import java.io.Serializable;
import java.security.SecureRandom;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.primefaces.model.file.UploadedFile;

import dao.CategoriaRelatoDAO;
import dao.EmpresaDAO;
import dao.FonteRelatoDAO;
import dao.RelatoDAO;
import dao.StatusRelatoDAO;
import dao.UsuarioDAO;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.CategoriaRelato;
import model.Empresa;
import model.FonteRelato;
import model.Relato;
import model.StatusRelato;
import model.Usuario;

@Named("relatoBeanCCPR")
@ViewScoped
public class RelatoBeanCCPR implements Serializable{
	private static final long serialVersionUID = 7320171252504345607L;
	private static final String CHAR_SET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private static SecureRandom random = new SecureRandom();
	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMddHHmmss");
	private UploadedFile file;
	private String chaveRelato;
	private static final Set<LocalDate> HOLIDAYS = new HashSet<>();

	// RELATO EM BRANCO QUE SERÁ SALVO
	Relato relato = new Relato(); // NOVO RELATO A SER CADASTRADO

	// LISTA QUE SERÁ PREENCHIDA NO FORMULÁRIO
	private List<CategoriaRelato> categoriaRelatos; // INSERIDO PELO USUÁRIO NO FORMULÁRIO

	// INSERINDO USUÁRIO PADRÃO
	private UsuarioDAO usuarioDAO = new UsuarioDAO();
	private Usuario usuario = usuarioDAO.buscarPorCodigo(1);

	// INSERINDO EMPRESA PADRÃO
	private EmpresaDAO empresaDAO = new EmpresaDAO();
	private Empresa empresa = empresaDAO.buscarPorCodigo(1);

	// INSERINDO FONTE RELATO PADRÃO
	private FonteRelatoDAO fonteRelatoDAO = new FonteRelatoDAO();
	private FonteRelato fonteRelato = fonteRelatoDAO.buscarPorCodigo(1);

	// INSERINDO STATUS RELATO PADRÃO
	private StatusRelatoDAO statusRelatoDAO = new StatusRelatoDAO();
	private StatusRelato statusRelato = statusRelatoDAO.buscarPorCodigo(1);

	@PostConstruct
	public void init() {
		HOLIDAYS.add(LocalDate.of(2025, 1, 1)); // Ano Novo
		HOLIDAYS.add(LocalDate.of(2025, 3, 3)); // Carnaval
		HOLIDAYS.add(LocalDate.of(2025, 3, 4)); // Carnaval
		HOLIDAYS.add(LocalDate.of(2025, 3, 5)); // Quarta-feira de Cinzas (meio-dia)
		HOLIDAYS.add(LocalDate.of(2025, 4, 18)); // Sexta-feira Santa
		HOLIDAYS.add(LocalDate.of(2025, 4, 21)); // Tiradentes
		HOLIDAYS.add(LocalDate.of(2025, 5, 1)); // Dia do Trabalho
		HOLIDAYS.add(LocalDate.of(2025, 6, 19)); // Corpus Christi
		HOLIDAYS.add(LocalDate.of(2025, 9, 7)); // Independência do Brasil
		HOLIDAYS.add(LocalDate.of(2025, 10, 12)); // Nossa Senhora Aparecida
		HOLIDAYS.add(LocalDate.of(2025, 11, 2)); // Finados
		HOLIDAYS.add(LocalDate.of(2025, 11, 15)); // Proclamação da República
		HOLIDAYS.add(LocalDate.of(2025, 12, 25)); // Natal

	}

	// get e set da classe principal relato
	public Relato getRelato() {
		return relato;
	}

	public void setRelato(Relato relato) {
		this.relato = relato;
	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	public String getChaveRelato() {
		return chaveRelato;
	}

	public void setChaveRelato(String chaveRelato) {
		this.chaveRelato = chaveRelato;
	}

	public List<CategoriaRelato> getCategoriaRelatos() {
		if (categoriaRelatos == null) {
			CategoriaRelatoDAO categoriaRelatoDAO = new CategoriaRelatoDAO();
			categoriaRelatos = categoriaRelatoDAO.buscarTodos();
		}
		return categoriaRelatos;
	}

	public String save() {
		chaveRelato = geraChaveUnica();
		RelatoDAO dao = new RelatoDAO();
		relato.setUsuario(usuario);
		relato.setEmpresa(empresa);
		relato.setFonteRelato(fonteRelato);
		relato.setStatus(statusRelato);
		relato.setDtCadastro(new Date());
		relato.setChaveAcesso(chaveRelato);
		if (relato.getCategoriaRelato() != null && relato.getCategoriaRelato().getPrazoDias() > 0) {
			relato.setDtVencimento(calculateDueDate(relato.getCategoriaRelato().getPrazoDias()));
		}
		if (file != null && file.getSize() <= 5242880) {
			relato.setAnexo(file.getContent());
		}
		dao.save(relato);
		return "cadastrorelato3.xhtml?faces-redirect=true&chaverelato=" + chaveRelato;
	}

	// MÉTODO GERA CHAVE UNICA
	public static String geraChaveUnica() {
		LocalDateTime agora = LocalDateTime.now();
		String prefixoDataHora = dtf.format(agora);
		StringBuilder sb = new StringBuilder(prefixoDataHora);
		for (int i = 0; i < 5; i++) {
			int index = random.nextInt(CHAR_SET.length());
			sb.append(CHAR_SET.charAt(index));
		}
		return sb.toString();
	}

	// Método para calcular a data de vencimento considerando apenas dias úteis
	private Date calculateDueDate(int prazo) {
		LocalDate date = LocalDate.now();
		int addedDays = 0;
		while (addedDays < prazo) {
			date = date.plusDays(1);
			if (isBusinessDay(date)) {
				addedDays++;
			}
		}
		return java.sql.Date.valueOf(date);
	}

	// Método para verificar se uma data é um dia útil
	private boolean isBusinessDay(LocalDate date) {
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		return dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY && !HOLIDAYS.contains(date);
	}

}
