package bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import dao.FonteRelatoDAO;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.FonteRelato;

@Named("fonteRelatoBean")
@ViewScoped
public class FonteRelatoBean implements Serializable{
	private static final long serialVersionUID = 3340399065463237640L;
	private FonteRelato fonteRelato = new FonteRelato();
	private List<FonteRelato> fonteRelatos;

	public FonteRelato getFonteRelato() {
		return fonteRelato;
	}

	public void setFonteRelato(FonteRelato fonteRelato) {
		this.fonteRelato = fonteRelato;
	}

	public List<FonteRelato> getFonteRelatos() {
		if (fonteRelatos == null) {
			refreshLista();
		}
		return fonteRelatos;
	}

	public void salvar() {
		FonteRelatoDAO dao = new FonteRelatoDAO();
		if (fonteRelato.getCodigo() == 0) {
			fonteRelato.setDtCadastro(new Date());
			dao.salvar(fonteRelato);
		} else {
			dao.atualizar(fonteRelato);
		}
		refreshLista();
		fonteRelato = new FonteRelato();
	}

	public void novo() {
		fonteRelato = new FonteRelato();
	}

	public void excluir(FonteRelato fonteRelato) {
		FonteRelatoDAO dao = new FonteRelatoDAO();
		dao.excluir(fonteRelato);
		refreshLista();
	}

	public void editar(FonteRelato fonteRelato) {
		this.fonteRelato = fonteRelato;
	}

	public void pesquisarPorNome() {
		FonteRelatoDAO dao = new FonteRelatoDAO();
		fonteRelatos = dao.buscarPorNome(fonteRelato.getNome());
	}

	private void refreshLista() {
		FonteRelatoDAO dao = new FonteRelatoDAO();
		fonteRelatos = dao.buscarTodos();
	}
}
