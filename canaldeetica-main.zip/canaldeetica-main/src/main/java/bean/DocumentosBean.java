package bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.tika.Tika;
import org.primefaces.model.file.UploadedFile;

import dao.DocumentosDAO;
import dao.EmpresaDAO;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletResponse;
import model.Documentos;
import model.Empresa;

@Named("documentosBean")
@ViewScoped
public class DocumentosBean implements Serializable{
	private static final long serialVersionUID = 4340770258380643723L;
	// ATRIBUTOS E OBJETOS DO BEAN[

	private Documentos documentos = new Documentos();
	private List<Documentos>documentosList;
	private List<Empresa> empresas;
	private UploadedFile file;

	// GETTERS E SETTERS DA CLASSE BEAN
	public List<Documentos> getDocumentosList(){
		if(documentosList == null) {
			refreshList();
		}
		return documentosList;
	}
	
	private void refreshList() {
		DocumentosDAO documentosDAO = new DocumentosDAO();
		documentosList = documentosDAO.findAll();
	}
	
	public List<Empresa> getEmpresas() {
		if (empresas == null) {
			EmpresaDAO empresaDAO = new EmpresaDAO();
			empresas = empresaDAO.buscarTodos();
		}
		return empresas;
	}

	public Documentos getDocumentos() {
		return documentos;
	}

	public void setDocumentos(Documentos documentos) {
		this.documentos = documentos;
	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	// METODOS DO BEAN

	public void save() {
		DocumentosDAO documentosDAO = new DocumentosDAO();
		if(documentos.getCodigo()==0) {
			if (file != null && file.getSize() <= 5242880) {
				documentos.setAnexo(file.getContent());
			}
			documentos.setDtCadastro(new Date());
			documentosDAO.save(documentos);
		} else {
			documentosDAO.update(documentos);
		}
		refreshList();
		documentos = new Documentos();
	}
	
	public void delete(Documentos documentos) {
        DocumentosDAO documentosDAO = new DocumentosDAO();
        documentosDAO.delete(documentos);
        refreshList();
    }
	
	public void downloadAnexo(Documentos documentos) {
		try {
			if (documentos != null && documentos.getAnexo() != null) {
				FacesContext fc = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) fc.getExternalContext().getResponse();

				Tika tika = new Tika();
				String contentType = tika.detect(documentos.getAnexo());
				String fileExtension = getFileExtension(contentType);

				response.reset();
				response.setContentType(contentType);
				response.setHeader("Content-Disposition", "attachment; filename=\"anexo" + fileExtension + "\"");

				response.getOutputStream().write(documentos.getAnexo());
				response.getOutputStream().flush();
				response.getOutputStream().close();

				fc.responseComplete();
			} else {
				System.out.println("Relato ou anexo é nulo.");
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar escrever o anexo na resposta.");
		}
	}
	
	private String getFileExtension(String mimeType) {
		switch (mimeType) {
		case "image/jpeg":
			return ".jpg";
		case "image/png":
			return ".png";
		case "image/gif":
			return ".gif";
		case "application/pdf":
			return ".pdf";
		default:
			return "";
		}
	}
}
