package bean;

import java.io.Serializable;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.primefaces.model.file.UploadedFile;

import dao.CategoriaRelatoDAO;
import dao.EmpresaDAO;
import dao.FonteRelatoDAO;
import dao.RelatoDAO;
import dao.StatusRelatoDAO;
import dao.UsuarioDAO;
import jakarta.annotation.ManagedBean;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.CategoriaRelato;
import model.Empresa;
import model.FonteRelato;
import model.Relato;
import model.StatusRelato;
import model.Usuario;

@Named("relatoBean")
@ViewScoped
public class RelatoBean implements Serializable{
	private static final long serialVersionUID = -5244719954953078992L;
	private static final String CHAR_SET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private static SecureRandom random = new SecureRandom();
	private static final DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyMMddHHmmss");
	private UploadedFile file;
	private boolean isEditMode = false;

	Relato relato = new Relato();
	private List<Relato> relatoList;
	private List<Usuario> usuarios;
	private List<Empresa> empresas;
	private List<FonteRelato> fonteRelatos;
	private List<CategoriaRelato> categoriaRelatos;
	private List<StatusRelato> statusRelatos;
	private Date today;
	private static final Set<LocalDate> HOLIDAYS = new HashSet<>();

	@PostConstruct
	public void init() {

		refreshLista();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		today = new Date();

		HOLIDAYS.add(LocalDate.of(2024, 1, 1)); // Ano Novo
		HOLIDAYS.add(LocalDate.of(2024, 2, 12)); // Carnaval
		HOLIDAYS.add(LocalDate.of(2024, 2, 13)); // Carnaval
		HOLIDAYS.add(LocalDate.of(2024, 2, 14)); // Quarta-feira de Cinzas (meio-dia)
		HOLIDAYS.add(LocalDate.of(2024, 3, 29)); // Sexta-feira Santa
		HOLIDAYS.add(LocalDate.of(2024, 4, 21)); // Tiradentes
		HOLIDAYS.add(LocalDate.of(2024, 5, 1)); // Dia do Trabalho
		HOLIDAYS.add(LocalDate.of(2024, 5, 30)); // Corpus Christi
		HOLIDAYS.add(LocalDate.of(2024, 9, 7)); // Independência do Brasil
		HOLIDAYS.add(LocalDate.of(2024, 10, 12)); // Nossa Senhora Aparecida
		HOLIDAYS.add(LocalDate.of(2024, 11, 2)); // Finados
		HOLIDAYS.add(LocalDate.of(2024, 11, 15)); // Proclamação da República
		HOLIDAYS.add(LocalDate.of(2024, 12, 25)); // Natal

	}

	// get e set da classe principal relato
	public Relato getRelato() {
		return relato;
	}

	public void setRelato(Relato relato) {
		this.relato = relato;
	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	public boolean getIsEditMode() {
		return isEditMode;
	}

	public void setEditMode(boolean isEditMode) {
		this.isEditMode = isEditMode;
	}

	// lista da classe principal relato
	public List<Relato> getRelatoList() {
		if (relatoList == null) {
			refreshLista();
		}
		return relatoList;
	}

	// demais lists que precisamos em relato
	public List<Usuario> getUsuarios() {
		if (usuarios == null) {
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarios = usuarioDAO.buscarTodos();
		}
		return usuarios;
	}

	public List<Empresa> getEmpresas() {
		if (empresas == null) {
			EmpresaDAO empresaDAO = new EmpresaDAO();
			empresas = empresaDAO.buscarTodos();
		}
		return empresas;
	}

	public List<FonteRelato> getFonteRelatos() {
		if (fonteRelatos == null) {
			FonteRelatoDAO fonteRelatosDAO = new FonteRelatoDAO();
			fonteRelatos = fonteRelatosDAO.buscarTodos();
		}
		return fonteRelatos;
	}

	public List<CategoriaRelato> getCategoriaRelatos() {
		if (categoriaRelatos == null) {
			CategoriaRelatoDAO categoriaRelatoDAO = new CategoriaRelatoDAO();
			categoriaRelatos = categoriaRelatoDAO.buscarTodos();
		}
		return categoriaRelatos;
	}

	public List<StatusRelato> getStatusRelatos() {
		if (statusRelatos == null) {
			StatusRelatoDAO statusRelatoDAO = new StatusRelatoDAO();
			statusRelatos = statusRelatoDAO.buscarTodos();
		}
		return statusRelatos;
	}

	public Date getToday() {
		return today;
	}

	public void setToday(Date today) {
		this.today = today;
	}

	public void save() {
		RelatoDAO dao = new RelatoDAO();
		if (relato.getCodigo() == 0) {
			relato.setDtCadastro(new Date());
			relato.setChaveAcesso(geraChaveUnica());
			if (relato.getCategoriaRelato() != null && relato.getCategoriaRelato().getPrazoDias() > 0) {
				relato.setDtVencimento(calculateDueDate(relato.getCategoriaRelato().getPrazoDias()));
			}
			if (file != null && file.getSize() <= 5242880) {
				relato.setAnexo(file.getContent());
			}
			this.isEditMode = false;
			dao.save(relato);
		} else {
			if(relato.getStatus().getCodigo()==4) {
				relato.setDtConclusao(today);
			}
			dao.update(relato);
		}
		refreshLista();
		relato = new Relato();
	}

	public void editar(Relato relato) {
		if ("Novo".equals(relato.getStatus().getNome())) {
			StatusRelatoDAO statusRelatoDAO = new StatusRelatoDAO();
			StatusRelato statusAberto = statusRelatoDAO.buscarPorCodigo(2);
			relato.setStatus(statusAberto);
		}
		this.relato = relato;
		this.isEditMode = true;
	}

	// metodo que carrega lista de relatos
	private void refreshLista() {
		RelatoDAO dao = new RelatoDAO();
		relatoList = dao.findAll();
	}

	// metodo que gera a chave unica para acesso do relato por usuario externo
	public static String geraChaveUnica() {
		LocalDateTime agora = LocalDateTime.now();
		String prefixoDataHora = dtf.format(agora);
		StringBuilder sb = new StringBuilder(prefixoDataHora);
		for (int i = 0; i < 5; i++) {
			int index = random.nextInt(CHAR_SET.length());
			sb.append(CHAR_SET.charAt(index));
		}
		return sb.toString();
	}

	public boolean isToday(Date date) {
		if (date == null) {
			return false;
		}
		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal1.setTime(date);
		cal2.setTime(today);
		return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)
				&& cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
	}

	// Método para calcular a data de vencimento considerando apenas dias úteis
	private Date calculateDueDate(int prazo) {
		LocalDate date = LocalDate.now();
		int addedDays = 0;
		while (addedDays < prazo) {
			date = date.plusDays(1);
			if (isBusinessDay(date)) {
				addedDays++;
			}
		}
		return java.sql.Date.valueOf(date);
	}

	// Método para verificar se uma data é um dia útil
	private boolean isBusinessDay(LocalDate date) {
		DayOfWeek dayOfWeek = date.getDayOfWeek();
		return dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY && !HOLIDAYS.contains(date);
	}

}
