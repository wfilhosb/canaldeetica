package bean;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.apache.tika.Tika;
import org.primefaces.model.file.UploadedFile;

import dao.AndamentoRelatoDAO;
import dao.RelatoDAO;
import dao.StatusRelatoDAO;
import dao.UsuarioDAO;
import jakarta.annotation.ManagedBean;
import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletResponse;
import model.AndamentoRelato;
import model.Relato;
import model.StatusRelato;
import model.Usuario;

@Named("detalhaRelatosBean")
@ViewScoped
public class DetalhaRelatosBean implements Serializable {
	private static final long serialVersionUID = 6455935030298146607L;
	// objetos e atributos da página


	private Relato relato = new Relato();
	private AndamentoRelato andamentoRelato = new AndamentoRelato();

	private RelatoDAO relatoDAO = new RelatoDAO();
	private AndamentoRelatoDAO andamaentoRelatoDAO = new AndamentoRelatoDAO();

	private List<AndamentoRelato> andamentos;
	private List<Usuario> usuarios;

	String codigoRelato;
	private UploadedFile file;
	private UploadedFile file2;

	@PostConstruct
	public void init() {
		codigoRelato = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap()
				.get("codigorelato");
		this.relato = relatoDAO.findRelatoByCodigo(Integer.parseInt(codigoRelato));
		refreshLista();
//		if ("Novo".equals(relato.getStatus().getNome())) {
//			StatusRelatoDAO statusRelatoDAO = new StatusRelatoDAO();
//			StatusRelato statusAberto = statusRelatoDAO.buscarPorCodigo(2);
//			this.relato.setStatus(statusAberto);
//			this.relatoDAO.save(relato);
//			this.relato = relatoDAO.findRelatoByCodigo(Integer.parseInt(codigoRelato));
//		}
	}

	// getters e setters
	public Relato getRelato() {
		return relato;
	}

	public void setRelato(Relato relato) {
		this.relato = relato;
	}

	public String getCodigoRelato() {
		return codigoRelato;
	}

	public void setCodigoRelato(String codigoRelato) {
		this.codigoRelato = codigoRelato;
	}

	public AndamentoRelato getAndamentoRelato() {
		return andamentoRelato;
	}

	public void setAndamentoRelato(AndamentoRelato andamentoRelato) {
		this.andamentoRelato = andamentoRelato;
	}

	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}

	public UploadedFile getFile2() {
		return file2;
	}

	public void setFile2(UploadedFile file2) {
		this.file2 = file2;
	}

	public List<AndamentoRelato> getAndamentos() {
		return andamentos;
	}

	public void setAndamentos(List<AndamentoRelato> andamentos) {
		this.andamentos = andamentos;
	}

	public List<Usuario> getUsuarios() {
		if (usuarios == null) {
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarios = usuarioDAO.buscarTodos();
		}
		return usuarios;
	}

	// processamentos da página
	public void salvarAndamentoRelato() {
		if (file != null && file.getSize() <= 5242880) {
			andamentoRelato.setAnexo(file.getContent());
		}
		andamentoRelato.setRelato(this.relato);
		andamentoRelato.setDtAndamento(new Date());
		andamaentoRelatoDAO.salvar(andamentoRelato);
		andamentoRelato = new AndamentoRelato();
		if(this.relato.getStatus().getCodigo()==1) {
			StatusRelato novoStatus = new StatusRelato();
			StatusRelatoDAO novoStatusDAO = new StatusRelatoDAO();
			novoStatus = novoStatusDAO.buscarPorCodigo(2);
			this.relato.setStatus(novoStatus);
			relatoDAO.update(this.relato);
		}
		refreshLista();
	}

	public void refreshLista() {
		this.andamentos = andamaentoRelatoDAO.findAndamentosByRelatoId(Integer.parseInt(codigoRelato));
	}

	public void downloadAnexo() {
		try {
			if (relato != null && relato.getAnexo() != null) {
				FacesContext fc = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) fc.getExternalContext().getResponse();

				Tika tika = new Tika();
				String contentType = tika.detect(relato.getAnexo());
				String fileExtension = getFileExtension(contentType);

				response.reset();
				response.setContentType(contentType);
				response.setHeader("Content-Disposition", "attachment; filename=\"anexo" + fileExtension + "\"");

				response.getOutputStream().write(relato.getAnexo());
				response.getOutputStream().flush();
				response.getOutputStream().close();

				fc.responseComplete();
			} else {
				System.out.println("Relato ou anexo é nulo.");
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar escrever o anexo na resposta.");
		}
	}

	public void downloadAnexoAndamento(AndamentoRelato andamentoRelato) {
		try {
			if (andamentoRelato != null && andamentoRelato.getAnexo() != null) {
				FacesContext fc = FacesContext.getCurrentInstance();
				HttpServletResponse response = (HttpServletResponse) fc.getExternalContext().getResponse();

				Tika tika = new Tika();
				String contentType = tika.detect(andamentoRelato.getAnexo());
				String fileExtension = getFileExtension(contentType);

				response.reset();
				response.setContentType(contentType);
				response.setHeader("Content-Disposition", "attachment; filename=\"anexo" + fileExtension + "\"");

				response.getOutputStream().write(andamentoRelato.getAnexo());
				response.getOutputStream().flush();
				response.getOutputStream().close();

				fc.responseComplete();
			} else {
				System.out.println("Andamento ou anexo é nulo.");
			}
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Erro ao tentar escrever o anexo na resposta.");
		}
	}

	private String getFileExtension(String mimeType) {
		switch (mimeType) {
		case "image/jpeg":
			return ".jpg";
		case "image/png":
			return ".png";
		case "image/gif":
			return ".gif";
		case "application/pdf":
			return ".pdf";
		default:
			return "";
		}
	}

}
