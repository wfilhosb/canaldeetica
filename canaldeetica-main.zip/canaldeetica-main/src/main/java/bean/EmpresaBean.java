package bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import dao.EmpresaDAO;
import dao.UsuarioDAO;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.Empresa;
import model.Usuario;

@Named("empresaBean")
@ViewScoped
public class EmpresaBean implements Serializable{
	private static final long serialVersionUID = 3660016473638676606L;
	private Empresa empresa = new Empresa();
	private List<Empresa> empresas;
	private List<Usuario> usuarios;
	private String nomePesquisa;

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public List<Empresa> getEmpresas() {
		if (empresas == null) {
			refreshLista();
		}
		return empresas;
	}

	public List<Usuario> getUsuarios() {
		if (usuarios == null) {
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarios = usuarioDAO.buscarTodos();
		}
		return usuarios;
	}

	public String getNomePesquisa() {
		return nomePesquisa;
	}

	public void setNomePesquisa(String nomePesquisa) {
		this.nomePesquisa = nomePesquisa;
	}

	public void salvar() {
		EmpresaDAO dao = new EmpresaDAO();
		if (empresa.getCodigo() == 0) {
			empresa.setDtCadastro(new Date());
			dao.salvar(empresa);
		} else {
			dao.atualizar(empresa);
		}
		refreshLista();
		empresa = new Empresa();
	}

	public void novo() {
		empresa = new Empresa();
		empresa.setDtCadastro(new Date());
	}

	public void excluir(Empresa empresa) {
		EmpresaDAO dao = new EmpresaDAO();
		dao.excluir(empresa);
		refreshLista();
	}

	public void editar(Empresa empresa) {
		this.empresa = empresa;
	}

	private void refreshLista() {
		EmpresaDAO dao = new EmpresaDAO();
		empresas = dao.buscarTodos();
	}

	public void pesquisarPorNome() {
		EmpresaDAO dao = new EmpresaDAO();
		empresas = dao.buscarPorNome(nomePesquisa);
	}
}
