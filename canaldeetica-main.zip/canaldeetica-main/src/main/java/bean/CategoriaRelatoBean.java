package bean;



import java.io.Serializable;
import java.util.Date;
import java.util.List;

import dao.CategoriaRelatoDAO;
import dao.EmpresaDAO;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.CategoriaRelato;
import model.Empresa;

@Named("categoriaRelatoBean")
@ViewScoped
public class CategoriaRelatoBean implements Serializable{
	private static final long serialVersionUID = -2974729003421157059L;
	private CategoriaRelato categoriaRelato = new CategoriaRelato();
    private List<CategoriaRelato> categoriasRelato;
    private List<Empresa> empresas;
    private String nomePesquisa;

    public CategoriaRelato getCategoriaRelato() {
        return categoriaRelato;
    }

    public void setCategoriaRelato(CategoriaRelato categoriaRelato) {
        this.categoriaRelato = categoriaRelato;
    }

    public List<CategoriaRelato> getCategoriasRelato() {
        if (categoriasRelato == null) {
            refreshLista();
        }
        return categoriasRelato;
    }

    public List<Empresa> getEmpresas() {
        if (empresas == null) {
            EmpresaDAO empresaDAO = new EmpresaDAO();
            empresas = empresaDAO.buscarTodos();
        }
        return empresas;
    }

    public String getNomePesquisa() {
        return nomePesquisa;
    }

    public void setNomePesquisa(String nomePesquisa) {
        this.nomePesquisa = nomePesquisa;
    }

    public void pesquisarPorNome() {
        CategoriaRelatoDAO dao = new CategoriaRelatoDAO();
        categoriasRelato = dao.buscarPorNome(nomePesquisa);
    }

    public void salvar() {
        CategoriaRelatoDAO dao = new CategoriaRelatoDAO();
        if (categoriaRelato.getCodigo() == 0) {
        	//COLOCAR A DATA NA CATEGORIA RELATO
        	categoriaRelato.setDtCadastro(new Date());
            dao.salvar(categoriaRelato);
        } else {
            dao.atualizar(categoriaRelato);
        }
        refreshLista();
        categoriaRelato = new CategoriaRelato();
    }

    public void novo() {
        categoriaRelato = new CategoriaRelato();
        //COLCOAR AQUI UMA DATA TBM
        categoriaRelato.setDtCadastro(new Date());
    }

    public void excluir(CategoriaRelato categoriaRelato) {
        CategoriaRelatoDAO dao = new CategoriaRelatoDAO();
        dao.excluir(categoriaRelato);
        refreshLista();
    }

    public void editar(CategoriaRelato categoriaRelato) {
        this.categoriaRelato = categoriaRelato;
    }

    private void refreshLista() {
        CategoriaRelatoDAO dao = new CategoriaRelatoDAO();
        categoriasRelato = dao.buscarTodos();
    }
}
