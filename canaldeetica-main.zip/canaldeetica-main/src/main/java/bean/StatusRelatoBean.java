package bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import dao.StatusRelatoDAO;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.StatusRelato;

@Named("statusRelatoBean")
@ViewScoped
public class StatusRelatoBean implements Serializable{
	private static final long serialVersionUID = 8256569865607318863L;
	private StatusRelato statusRelato = new StatusRelato();
	private List<StatusRelato> statusRelatos;

	public StatusRelato getStatusRelato() {
		return statusRelato;
	}

	public void setStatusRelato(StatusRelato statusRelato) {
		this.statusRelato = statusRelato;
	}

	public List<StatusRelato> getStatusRelatos() {
		if (statusRelatos == null) {
			refreshLista();
		}
		return statusRelatos;
	}

	public void salvar() {
		StatusRelatoDAO dao = new StatusRelatoDAO();
		if (statusRelato.getCodigo() == 0) {
			statusRelato.setDtCadastro(new Date());
			dao.salvar(statusRelato);
		} else {
			dao.atualizar(statusRelato);
		}
		refreshLista();
		statusRelato = new StatusRelato();
	}

	public void novo() {
		statusRelato = new StatusRelato();
	}

	public void excluir(StatusRelato statusRelato) {
		StatusRelatoDAO dao = new StatusRelatoDAO();
		dao.excluir(statusRelato);
		refreshLista();
	}

	public void editar(StatusRelato statusRelato) {
		this.statusRelato = statusRelato;
	}

	public void pesquisarPorNome() {
		StatusRelatoDAO dao = new StatusRelatoDAO();
		statusRelatos = dao.buscarPorNome(statusRelato.getNome());
	}

	private void refreshLista() {
		StatusRelatoDAO dao = new StatusRelatoDAO();
		statusRelatos = dao.buscarTodos();
	}
}
