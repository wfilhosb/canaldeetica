package bean;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import dao.UsuarioDAO;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import model.Usuario;

@Named("usuarioBean")
@ViewScoped
public class UsuarioBean implements Serializable{
	private static final long serialVersionUID = 5141412856034595921L;
	private Usuario usuario = new Usuario();
	private List<Usuario> usuarios;
	private String senhaConfirmacao;

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getSenhaConfirmacao() {
		return senhaConfirmacao;
	}

	public void setSenhaConfirmacao(String senhaConfirmacao) {
		this.senhaConfirmacao = senhaConfirmacao;
	}

	public List<Usuario> getUsuarios() {
		if (usuarios == null) {
			refreshLista();
		}
		return usuarios;
	}

	public void salvar() {
		UsuarioDAO dao = new UsuarioDAO();
		if (usuario.getCodigo() == 0) {
			usuario.setDtCadastro(new Date());
			dao.salvar(usuario);
		} else {
			dao.atualizar(usuario);
		}
		refreshLista();
		usuario = new Usuario();
		this.senhaConfirmacao = "";
	}

	public void novo() {
		usuario = new Usuario();
	}

	public void excluir(Usuario usuario) {
		UsuarioDAO dao = new UsuarioDAO();
		dao.excluir(usuario);
		refreshLista();
	}

	public void editar(Usuario usuario) {
		this.usuario = usuario;
		this.setSenhaConfirmacao(usuario.getSenha()); // Adicione isso se ainda não estiver
	}

	public void pesquisarPorLogin() {
		UsuarioDAO dao = new UsuarioDAO();
		usuarios.clear();
		usuarios.add(dao.buscarPorLogin(usuario.getLogin()));
	}

	private void refreshLista() {
		UsuarioDAO dao = new UsuarioDAO();
		usuarios = dao.buscarTodos();
	}
}
