package service;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

import com.google.gson.Gson;

import dao.RelatoDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/contagemCategoriaRelato")
public class ContagemCategoriaRelatoServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");

		RelatoDAO relatoDAO = new RelatoDAO(); // Instancie aqui com o seu EntityManager

        Map<String, Integer> contagemCategoriaRelato = relatoDAO.contarCategoriaRelato();

        // Converte o mapa em JSON e envia como resposta
        PrintWriter out = response.getWriter();
        out.print(new Gson().toJson(contagemCategoriaRelato));
        out.flush();
    }
}
