package converter;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import canaldeetica.canaldeetica.HibernateUtil;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import model.CategoriaRelato;

@FacesConverter("categoriaRelatoConverter")
public class CategoriaRelatoConverter implements Converter {

    @PersistenceContext(unitName = "canaldeetica")
    private transient EntityManager em = HibernateUtil.getEntityManager();

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value != null && value.trim().length() > 0) {
            try {
                return em.find(CategoriaRelato.class, Integer.parseInt(value));
            } catch (NumberFormatException e) {
                throw new RuntimeException("Conversion error: invalid ID for CategoriaRelato entity", e);
            }
        }
        return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object object) {
        if (object != null && object instanceof CategoriaRelato) {
            return String.valueOf(((CategoriaRelato) object).getCodigo());
        }
        return "";
    }
}
