package converter;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import canaldeetica.canaldeetica.HibernateUtil;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import model.Usuario;

@FacesConverter("usuarioConverter")
public class UsuarioConverter implements Converter {
    
    @PersistenceContext(unitName = "canaldeetica")
    private transient EntityManager em = HibernateUtil.getEntityManager();;

    @Override
    public Object getAsObject(FacesContext fc, UIComponent uic, String value) {
        if (value != null && value.trim().length() > 0) {
            return em.find(Usuario.class, Integer.parseInt(value));
        }
        return null;
    }

    @Override
    public String getAsString(FacesContext fc, UIComponent uic, Object object) {
        if (object != null) {
            return String.valueOf(((Usuario) object).getCodigo());
        }
        return null;
    }
}
