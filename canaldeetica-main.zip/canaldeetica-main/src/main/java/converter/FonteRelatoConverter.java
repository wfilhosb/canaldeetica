package converter;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import canaldeetica.canaldeetica.HibernateUtil;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import model.FonteRelato;

@FacesConverter("fonteRelatoConverter")
public class FonteRelatoConverter implements Converter {

    @PersistenceContext(unitName = "canaldeetica")
    private transient EntityManager em = HibernateUtil.getEntityManager();

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value != null && value.trim().length() > 0) {
            try {
                return em.find(FonteRelato.class, Integer.valueOf(value));
            } catch (NumberFormatException e) {
                throw new RuntimeException("Conversion error: invalid ID for FonteRelato entity", e);
            }
        }
        return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value != null && value instanceof FonteRelato) {
            return String.valueOf(((FonteRelato) value).getCodigo());
        }
        return null;
    }
}