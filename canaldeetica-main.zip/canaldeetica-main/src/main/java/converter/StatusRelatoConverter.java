package converter;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import canaldeetica.canaldeetica.HibernateUtil;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import model.StatusRelato;

@FacesConverter("statusRelatoConverter")
public class StatusRelatoConverter implements Converter {

    @PersistenceContext(unitName = "canaldeetica")
    private EntityManager em = HibernateUtil.getEntityManager();

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value != null && value.trim().length() > 0) {
            try {
                return em.find(StatusRelato.class, Integer.valueOf(value));
            } catch (NumberFormatException e) {
                throw new RuntimeException("Conversion error: invalid ID for StatusRelato entity", e);
            }
        }
        return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value != null && value instanceof StatusRelato) {
            return String.valueOf(((StatusRelato) value).getCodigo());
        }
        return null;
    }
}