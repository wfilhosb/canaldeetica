package converter;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import canaldeetica.canaldeetica.HibernateUtil;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import jakarta.faces.convert.Converter;
import jakarta.faces.convert.FacesConverter;
import model.Empresa;

@FacesConverter("empresaConverter")
public class EmpresaConverter implements Converter {

    @PersistenceContext(unitName = "canaldeetica")
    private transient EntityManager em = HibernateUtil.getEntityManager();

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
        if (value != null && value.trim().length() > 0) {
            try {
                return em.find(Empresa.class, Integer.valueOf(value));
            } catch (NumberFormatException e) {
                throw new RuntimeException("Conversion error: invalid value for Empresa entity", e);
            }
        }
        return null;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
        if (value != null && value instanceof Empresa) {
            return String.valueOf(((Empresa) value).getCodigo());
        }
        return null;
    }
}