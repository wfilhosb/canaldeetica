package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.StatusRelato;

public class StatusRelatoDAO {

	// Método para salvar um StatusRelato
	public void salvar(StatusRelato statusRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(statusRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para atualizar um StatusRelato
	public void atualizar(StatusRelato statusRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(statusRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para excluir um StatusRelato
	public void excluir(StatusRelato statusRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.contains(statusRelato) ? statusRelato : em.merge(statusRelato));
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos os StatusRelatos
	public List<StatusRelato> buscarTodos() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<StatusRelato> query = em.createQuery("SELECT s FROM StatusRelato s", StatusRelato.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para buscar StatusRelatos por nome
	public List<StatusRelato> buscarPorNome(String nome) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<StatusRelato> query = em.createQuery("SELECT s FROM StatusRelato s WHERE s.nome LIKE :nome",
					StatusRelato.class);
			query.setParameter("nome", "%" + nome + "%");
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	public StatusRelato buscarPorCodigo(int codigo) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			return em.find(StatusRelato.class, codigo);
		} finally {
			em.close();
		}
	}
}
