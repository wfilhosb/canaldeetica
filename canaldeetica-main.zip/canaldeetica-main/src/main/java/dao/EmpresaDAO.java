package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.Empresa;

public class EmpresaDAO {

	// Método para salvar uma Empresa
	public void salvar(Empresa empresa) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(empresa);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para atualizar uma Empresa
	public void atualizar(Empresa empresa) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(empresa);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para excluir uma Empresa
	public void excluir(Empresa empresa) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.contains(empresa) ? empresa : em.merge(empresa));
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos as Empresas
	public List<Empresa> buscarTodos() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Empresa> query = em.createQuery("SELECT e FROM Empresa e", Empresa.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para buscar Empresas por nome
	public List<Empresa> buscarPorNome(String nome) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Empresa> query = em.createQuery("SELECT e FROM Empresa e WHERE e.nomeFantasia LIKE :nome",
					Empresa.class);
			query.setParameter("nome", "%" + nome + "%");
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	public Empresa buscarPorCodigo(int codigo) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			return em.find(Empresa.class, codigo);
		} finally {
			em.close();
		}
	}
}
