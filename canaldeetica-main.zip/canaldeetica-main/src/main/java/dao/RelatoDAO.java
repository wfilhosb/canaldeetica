package dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import canaldeetica.canaldeetica.HibernateUtil;
import model.Relato;

@Repository
public class RelatoDAO {

	// Método para salvar um Relato
	public void save(Relato relato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(relato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para atualizar um Relato
	public void update(Relato relato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(relato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos os Relatos
	public List<Relato> findAll() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Relato> query = em.createQuery("SELECT r FROM Relato r", Relato.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para buscar um Relato pelo código
	public Relato findRelatoByCodigo(int codigo) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			String jpql = "SELECT r FROM Relato r WHERE r.codigo = :codigo";
			TypedQuery<Relato> query = em.createQuery(jpql, Relato.class);
			query.setParameter("codigo", codigo);
			return query.getSingleResult(); // Retorna o relato correspondente ou null se não encontrado
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}
	}

	public Map<String, Integer> contarStatus() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			String jpql = "SELECT r.status.nome, COUNT(r) FROM Relato r GROUP BY r.status.nome";
			TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
			List<Object[]> resultados = query.getResultList();

			Map<String, Integer> contagemStatus = new HashMap<>();
			for (Object[] resultado : resultados) {
				String nomeStatus = (String) resultado[0];
				Long quantidade = (Long) resultado[1];
				contagemStatus.put(nomeStatus, quantidade.intValue());
			}

			return contagemStatus;
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}

	}

	public Map<String, Integer> contarFonteRelato() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			String jpql = "SELECT r.fonteRelato.nome, COUNT(r) FROM Relato r GROUP BY r.fonteRelato.nome";
			TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
			List<Object[]> resultados = query.getResultList();

			Map<String, Integer> contagemFonteRelato = new HashMap<>();
			for (Object[] resultado : resultados) {
				String nomeFonteRelato = (String) resultado[0];
				Long quantidade = (Long) resultado[1];
				contagemFonteRelato.put(nomeFonteRelato, quantidade.intValue());
			}

			return contagemFonteRelato;
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}
	}

	public Map<String, Integer> contarCategoriaRelato() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			String jpql = "SELECT r.categoriaRelato.nome, COUNT(r) FROM Relato r GROUP BY r.categoriaRelato.nome";
			TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
			List<Object[]> resultados = query.getResultList();

			Map<String, Integer> contagemCategoriaRelato = new HashMap<>();
			for (Object[] resultado : resultados) {
				String nomeCategoriaRelato = (String) resultado[0];
				Long quantidade = (Long) resultado[1];
				contagemCategoriaRelato.put(nomeCategoriaRelato, quantidade.intValue());
			}

			return contagemCategoriaRelato;
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}
	}

	public Map<String, Integer> contarRelatosPorEmpresa() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			String jpql = "SELECT r.empresa.nomeFantasia, COUNT(r) FROM Relato r GROUP BY r.empresa.nomeFantasia";
			TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
			List<Object[]> resultados = query.getResultList();

			Map<String, Integer> contagemRelatosPorEmpresa = new HashMap<>();
			for (Object[] resultado : resultados) {
				String nomeFantasiaEmpresa = (String) resultado[0];
				Long quantidade = (Long) resultado[1];
				contagemRelatosPorEmpresa.put(nomeFantasiaEmpresa, quantidade.intValue());
			}

			return contagemRelatosPorEmpresa;
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}
	}

	public Relato buscarPorChaveAcesso(String chaveAcesso) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Relato> query = em.createQuery("SELECT r FROM Relato r WHERE r.chaveAcesso = :chaveAcesso",
					Relato.class);
			query.setParameter("chaveAcesso", chaveAcesso);
			return query.getSingleResult();
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}
	}

}
