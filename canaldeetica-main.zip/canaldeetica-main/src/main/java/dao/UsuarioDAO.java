package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.Usuario;

public class UsuarioDAO {

	// Método para salvar um usuário
	public void salvar(Usuario usuario) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(usuario);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para atualizar um usuário
	public void atualizar(Usuario usuario) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(usuario);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para excluir um usuário
	public void excluir(Usuario usuario) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.contains(usuario) ? usuario : em.merge(usuario));
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos os usuários
	public List<Usuario> buscarTodos() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Usuario> query = em.createQuery("SELECT u FROM Usuario u", Usuario.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para buscar um usuário por login
	public Usuario buscarPorLogin(String login) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Usuario> query = em.createQuery("SELECT u FROM Usuario u WHERE u.login = :login", Usuario.class);
			query.setParameter("login", login);
			return query.getSingleResult();
		} catch (Exception e) {
			// Handle exception if no result is found or any other database error
			return null;
		} finally {
			em.close();
		}
	}

	public Usuario buscarPorCodigo(int codigo) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			return em.find(Usuario.class, codigo);
		} finally {
			em.close();
		}
	}
}
