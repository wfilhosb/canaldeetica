package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.CategoriaRelato;

public class CategoriaRelatoDAO {

	// Método para salvar uma CategoriaRelato
	public void salvar(CategoriaRelato categoriaRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(categoriaRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para atualizar uma CategoriaRelato
	public void atualizar(CategoriaRelato categoriaRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(categoriaRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para excluir uma CategoriaRelato
	public void excluir(CategoriaRelato categoriaRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.contains(categoriaRelato) ? categoriaRelato : em.merge(categoriaRelato));
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos os CategoriaRelatos
	public List<CategoriaRelato> buscarTodos() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<CategoriaRelato> query = em.createQuery("SELECT c FROM CategoriaRelato c",
					CategoriaRelato.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para buscar CategoriaRelatos por nome
	public List<CategoriaRelato> buscarPorNome(String nome) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<CategoriaRelato> query = em
					.createQuery("SELECT c FROM CategoriaRelato c WHERE c.nome LIKE :nome", CategoriaRelato.class);
			query.setParameter("nome", "%" + nome + "%");
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	public CategoriaRelato buscarPorCodigo(int codigo) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			return em.find(CategoriaRelato.class, codigo);
		} finally {
			em.close();
		}
	}
}
