package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.AndamentoRelato;

public class AndamentoRelatoDAO {

	// Método para salvar um AndamentoRelato
	public void salvar(AndamentoRelato andamentoRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(andamentoRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos os Andamentos de um Relato específico
	public List<AndamentoRelato> findAndamentosByRelatoId(int relatoId) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			String jpql = "SELECT a FROM AndamentoRelato a WHERE a.relato.codigo = :relatoId ORDER BY a.dtAndamento DESC";
			TypedQuery<AndamentoRelato> query = em.createQuery(jpql, AndamentoRelato.class);
			query.setParameter("relatoId", relatoId);
			return query.getResultList();
		} finally {
			em.close();
		}
	}
}
