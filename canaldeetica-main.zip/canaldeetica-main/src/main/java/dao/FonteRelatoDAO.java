package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.FonteRelato;


public class FonteRelatoDAO {

	// Método para salvar uma FonteRelato
	public void salvar(FonteRelato fonteRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(fonteRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para atualizar uma FonteRelato
	public void atualizar(FonteRelato fonteRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(fonteRelato);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para excluir uma FonteRelato
	public void excluir(FonteRelato fonteRelato) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.contains(fonteRelato) ? fonteRelato : em.merge(fonteRelato));
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos as FonteRelatos
	public List<FonteRelato> buscarTodos() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<FonteRelato> query = em.createQuery("SELECT f FROM FonteRelato f", FonteRelato.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para buscar FonteRelatos por nome
	public List<FonteRelato> buscarPorNome(String nome) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<FonteRelato> query = em.createQuery("SELECT f FROM FonteRelato f WHERE f.nome LIKE :nome",
					FonteRelato.class);
			query.setParameter("nome", "%" + nome + "%");
			return query.getResultList();
		} finally {
			em.close();
		}
	}
	
	public FonteRelato buscarPorCodigo(int codigo) {
        EntityManager em = HibernateUtil.getEntityManager();
        try {
            return em.find(FonteRelato.class, codigo);
        } finally {
            em.close();
        }
    }
}
