package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import canaldeetica.canaldeetica.HibernateUtil;
import model.Documentos;

public class DocumentosDAO {
	// Método para salvar um Documento
	public void save(Documentos documentos) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(documentos);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para buscar todos os Documentos
	public List<Documentos> findAll() {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			TypedQuery<Documentos> query = em.createQuery("SELECT d FROM Documentos d", Documentos.class);
			return query.getResultList();
		} finally {
			em.close();
		}
	}

	// Método para atualizar um Relato
	public void update(Documentos documentos) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.merge(documentos);
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}

	// Método para excluir uma documentos
	public void delete(Documentos documentos) {
		EntityManager em = HibernateUtil.getEntityManager();
		try {
			em.getTransaction().begin();
			em.remove(em.contains(documentos) ? documentos : em.merge(documentos));
			em.getTransaction().commit();
		} catch (RuntimeException e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw e;
		} finally {
			em.close();
		}
	}
}
