 package model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Empresa {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int codigo;
	
	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private Usuario usuario;
	
	@Column(nullable = false)
	private String nomeFantasia;
	
	@Column(nullable = false)
	private String razaoSocial;
	
	@Column(nullable = false)
	private String cnpj;
	
	@Column(nullable = false)
	private String email;
	
	@Column(nullable = false)
	private String telefone;
	
	@Column(nullable = false)
	private String responsavel;
	
	@Column(nullable = false)
	private String celularResponsavel;
	
	@Column(nullable = false)
	private Date dtCadastro;
	
	@Column(nullable = true)
	private Date dtInativacao;
	
	@Column(nullable = true)
	private byte[] logo;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public String getNomeFantasia() {
		return nomeFantasia;
	}
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}
	public String getRazaoSocial() {
		return razaoSocial;
	}
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getResponsavel() {
		return responsavel;
	}
	public void setResponsavel(String responsavel) {
		this.responsavel = responsavel;
	}
	public String getCelularResponsavel() {
		return celularResponsavel;
	}
	public void setCelularResponsavel(String celularResponsavel) {
		this.celularResponsavel = celularResponsavel;
	}
	public Date getDtCadastro() {
		return dtCadastro;
	}
	public void setDtCadastro(Date dtCadastro) {
		this.dtCadastro = dtCadastro;
	}
	public Date getDtInativacao() {
		return dtInativacao;
	}
	public void setDtInativacao(Date dtInativacao) {
		this.dtInativacao = dtInativacao;
	}
	public byte[] getLogo() {
		return logo;
	}
	public void setLogo(byte[] logo) {
		this.logo = logo;
	}
	@Override
	public int hashCode() {
		return Objects.hash(celularResponsavel, cnpj, codigo, dtCadastro, dtInativacao, email, logo, nomeFantasia,
				razaoSocial, responsavel, telefone, usuario);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empresa other = (Empresa) obj;
		return Objects.equals(celularResponsavel, other.celularResponsavel) && Objects.equals(cnpj, other.cnpj)
				&& codigo == other.codigo && Objects.equals(dtCadastro, other.dtCadastro)
				&& Objects.equals(dtInativacao, other.dtInativacao) && Objects.equals(email, other.email)
				&& Objects.equals(logo, other.logo) && Objects.equals(nomeFantasia, other.nomeFantasia)
				&& Objects.equals(razaoSocial, other.razaoSocial) && Objects.equals(responsavel, other.responsavel)
				&& Objects.equals(telefone, other.telefone) && Objects.equals(usuario, other.usuario);
	}
	
	
}
