package model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class AndamentoRelato {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int codigo;
	
	@Column(nullable = false)
	private String titulo;
	
	@Column(nullable = false, length = 4000)
	private String descricao;
	
	@Column(nullable = false)
	private Date dtAndamento;
	
	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private Usuario usuario;
	
	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private Relato relato;
	
	@Column(nullable = true)
	private byte[] anexo;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public Date getDtAndamento() {
		return dtAndamento;
	}
	public void setDtAndamento(Date dtAndamento) {
		this.dtAndamento = dtAndamento;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Relato getRelato() {
		return relato;
	}
	public void setRelato(Relato relato) {
		this.relato = relato;
	}
	public byte[] getAnexo() {
		return anexo;
	}
	public void setAnexo(byte[] anexo) {
		this.anexo = anexo;
	}
	@Override
	public int hashCode() {
		return Objects.hash(anexo, codigo, descricao, dtAndamento, relato, titulo, usuario);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AndamentoRelato other = (AndamentoRelato) obj;
		return Objects.equals(anexo, other.anexo) && codigo == other.codigo
				&& Objects.equals(descricao, other.descricao) && Objects.equals(dtAndamento, other.dtAndamento)
				&& Objects.equals(relato, other.relato) && Objects.equals(titulo, other.titulo)
				&& Objects.equals(usuario, other.usuario);
	}
}
