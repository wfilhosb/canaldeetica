package model;

import java.util.Map;
import java.util.Objects;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RelatoPayloadPrestus {

	@JsonProperty("ID")
	private String id;

	@JsonProperty("Date")
	private String date;

	@JsonProperty("Time")
	private String time;

	@JsonProperty("UnixTimestamp")
	private String unixTimestamp;

	@JsonProperty("Description")
	private String description;

	@JsonProperty("Notes")
	private String notes;

	@JsonProperty("Status")
	private String status;

	@JsonProperty("Attendant")
	private String attendant;

	@JsonProperty("Q")
	private Map<String, String> q;

	@JsonProperty("A")
	private Map<String, String> a;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getUnixTimestamp() {
		return unixTimestamp;
	}

	public void setUnixTimestamp(String unixTimestamp) {
		this.unixTimestamp = unixTimestamp;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAttendant() {
		return attendant;
	}

	public void setAttendant(String attendant) {
		this.attendant = attendant;
	}

	public Map<String, String> getQ() {
		return q;
	}

	public void setQ(Map<String, String> q) {
		this.q = q;
	}

	public Map<String, String> getA() {
		return a;
	}

	public void setA(Map<String, String> a) {
		this.a = a;
	}

	@Override
	public int hashCode() {
		return Objects.hash(a, attendant, date, description, id, notes, q, status, time, unixTimestamp);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RelatoPayloadPrestus other = (RelatoPayloadPrestus) obj;
		return Objects.equals(a, other.a) && Objects.equals(attendant, other.attendant)
				&& Objects.equals(date, other.date) && Objects.equals(description, other.description)
				&& Objects.equals(id, other.id) && Objects.equals(notes, other.notes) && Objects.equals(q, other.q)
				&& Objects.equals(status, other.status) && Objects.equals(time, other.time)
				&& Objects.equals(unixTimestamp, other.unixTimestamp);
	}

}
