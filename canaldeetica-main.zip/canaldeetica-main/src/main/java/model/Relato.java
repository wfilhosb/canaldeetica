package model;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Relato {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int codigo;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private Usuario usuario;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private Empresa empresa;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private FonteRelato fonteRelato;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private CategoriaRelato categoriaRelato;

	@OneToMany(mappedBy = "relato")
	private List<AndamentoRelato> andamentos;

	@Column(nullable = false)
	private Date dtCadastro;

	@Column(nullable = true)
	private Date dtConclusao;

	@Column(nullable = true)
	private Date dtVencimento;

	@Column(nullable = false)
	private String titulo;

	@Column(nullable = false, length = 4000)
	private String descRelato;

	@Column(nullable = true)
	private String chaveAcesso;

	@Lob
	private byte[] anexo;

	@ManyToOne(optional = false, fetch = FetchType.EAGER)
	private StatusRelato status;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public FonteRelato getFonteRelato() {
		return fonteRelato;
	}

	public void setFonteRelato(FonteRelato fonteRelato) {
		this.fonteRelato = fonteRelato;
	}

	public CategoriaRelato getCategoriaRelato() {
		return categoriaRelato;
	}

	public void setCategoriaRelato(CategoriaRelato categoriaRelato) {
		this.categoriaRelato = categoriaRelato;
	}

	public Date getDtCadastro() {
		return dtCadastro;
	}

	public void setDtCadastro(Date dtCadastro) {
		this.dtCadastro = dtCadastro;
	}

	public Date getDtConclusao() {
		return dtConclusao;
	}

	public void setDtConclusao(Date dtConclusao) {
		this.dtConclusao = dtConclusao;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescRelato() {
		return descRelato;
	}

	public void setDescRelato(String descRelato) {
		this.descRelato = descRelato;
	}

	public String getChaveAcesso() {
		return chaveAcesso;
	}

	public void setChaveAcesso(String chaveAcesso) {
		this.chaveAcesso = chaveAcesso;
	}

	public byte[] getAnexo() {
		return anexo;
	}

	public void setAnexo(byte[] anexo) {
		this.anexo = anexo;
	}

	public StatusRelato getStatus() {
		return status;
	}

	public void setStatus(StatusRelato status) {
		this.status = status;
	}

	public List<AndamentoRelato> getAndamentos() {
		return andamentos;
	}

	public void setAndamentos(List<AndamentoRelato> andamentos) {
		this.andamentos = andamentos;
	}

	public Date getDtVencimento() {
		return dtVencimento;
	}

	public void setDtVencimento(Date dtVencimento) {
		this.dtVencimento = dtVencimento;
	}

	@Override
	public String toString() {
		return "Relato [codigo=" + codigo + ", titulo=" + titulo + ", descRelato=" + descRelato + ", chaveAcesso="
				+ chaveAcesso + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(anexo);
		result = prime * result + Objects.hash(andamentos, categoriaRelato, chaveAcesso, codigo, descRelato, dtCadastro,
				dtConclusao, dtVencimento, empresa, fonteRelato, status, titulo, usuario);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Relato other = (Relato) obj;
		return Objects.equals(andamentos, other.andamentos) && Arrays.equals(anexo, other.anexo)
				&& Objects.equals(categoriaRelato, other.categoriaRelato)
				&& Objects.equals(chaveAcesso, other.chaveAcesso) && codigo == other.codigo
				&& Objects.equals(descRelato, other.descRelato) && Objects.equals(dtCadastro, other.dtCadastro)
				&& Objects.equals(dtConclusao, other.dtConclusao) && Objects.equals(dtVencimento, other.dtVencimento)
				&& Objects.equals(empresa, other.empresa) && Objects.equals(fonteRelato, other.fonteRelato)
				&& Objects.equals(status, other.status) && Objects.equals(titulo, other.titulo)
				&& Objects.equals(usuario, other.usuario);
	}

}
